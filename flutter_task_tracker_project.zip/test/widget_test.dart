import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_task_tracker/main.dart';

void main() {
  testWidgets('App loads correctly', (WidgetTester tester) async {
    await tester.pumpWidget(TaskTrackerApp());
    expect(find.text('Task Tracker'), findsOneWidget);
  });
}
